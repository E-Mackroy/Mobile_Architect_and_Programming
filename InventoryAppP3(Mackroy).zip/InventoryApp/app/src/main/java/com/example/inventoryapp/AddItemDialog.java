package com.example.inventoryapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;

import androidx.annotation.NonNull;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;

public final class AddItemDialog {

    public interface Callback {
        void onAdd(String name, String location, int qty);
    }

    public static void show(@NonNull Context ctx, @NonNull Callback cb) {
        View content = LayoutInflater.from(ctx).inflate(R.layout.dialog_add_item, null, false);
        EditText inName = content.findViewById(R.id.inName);
        EditText inLocation = content.findViewById(R.id.inLocation);
        EditText inQty = content.findViewById(R.id.inQty);

        new MaterialAlertDialogBuilder(ctx)
                .setTitle(R.string.title_add_item)
                .setView(content)
                .setNegativeButton(R.string.cancel, null)
                .setPositiveButton(R.string.add, (d, w) -> {
                    String name = inName.getText() == null ? "" : inName.getText().toString().trim();
                    String loc  = inLocation.getText() == null ? "" : inLocation.getText().toString().trim();
                    int qty = 0;
                    try { qty = Integer.parseInt(inQty.getText().toString().trim()); } catch (Exception ignore) {}
                    if (!name.isEmpty()) cb.onAdd(name, loc, qty);
                })
                .show();
    }
}





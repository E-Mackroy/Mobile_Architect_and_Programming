package com.example.inventoryapp;  // <-- match your package

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class SmsPermissionFragment extends Fragment {

    private TextView tvStatus;
    private ActivityResultLauncher<String> requestSms;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Register the launcher here (safer than at field level)
        requestSms = registerForActivityResult(
                new ActivityResultContracts.RequestPermission(),
                isGranted -> {
                    if (!isAdded()) return; // fragment not attached anymore
                    if (isGranted) {
                        setStatus("SMS permission granted");
                        goToAlerts();
                    } else {
                        setStatus("SMS permission not granted");
                        // Stay here so the user can try again or tap Not now
                    }
                }
        );
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_sms_permission, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        tvStatus = view.findViewById(R.id.tvSmsStatus);
        Button btnEnable = view.findViewById(R.id.btnEnableSms);
        Button btnNotNow = view.findViewById(R.id.btnNotNow);

        btnEnable.setOnClickListener(v ->
                requestSms.launch(Manifest.permission.SEND_SMS));

        // Do NOT call back press here; navigate forward so the app never closes
        btnNotNow.setOnClickListener(v -> goToAlerts());

        // Auto jump if already granted, otherwise show a clear message
        boolean granted = ContextCompat.checkSelfPermission(
                requireContext(), Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;

        if (granted) {
            setStatus("SMS permission already granted");
            goToAlerts();
        } else {
            setStatus("SMS permission needed for alerts");
            // If you want the system dialog to appear right away, uncomment:
            // requestSms.launch(Manifest.permission.SEND_SMS);
        }
    }

    private void setStatus(String msg) {
        if (tvStatus != null) tvStatus.setText(msg);
    }

    private void goToAlerts() {
        if (!isAdded()) return;
        // Swap to your normal Alerts screen
        requireActivity().getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragment_container_view, new AlertsFragment())
                .commit();

        // Keep the bottom nav highlight in sync
        BottomNavigationView bottom = requireActivity().findViewById(R.id.bottom_nav);
        if (bottom != null) bottom.setSelectedItemId(R.id.menu_alerts);
    }
}

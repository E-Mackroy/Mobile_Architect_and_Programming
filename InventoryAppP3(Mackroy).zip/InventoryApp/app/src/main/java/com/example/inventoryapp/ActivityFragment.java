package com.example.inventoryapp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ActivityFragment extends Fragment {

    private ItemsViewModel vm;
    private ChangeAdapter adapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_activity, container, false);

        vm = new ViewModelProvider(requireActivity()).get(ItemsViewModel.class);

        RecyclerView rv = root.findViewById(R.id.rvActivity);
        rv.setLayoutManager(new LinearLayoutManager(requireContext()));
        adapter = new ChangeAdapter();
        rv.setAdapter(adapter);

        // Observe the activity feed
        vm.getActivity().observe(getViewLifecycleOwner(), adapter::submit);

        return root;
    }
    // ---------------- Adapter ----------------

    private static class ChangeAdapter extends RecyclerView.Adapter<ChangeVH> {
        private final List<ActivityEvent> data = new ArrayList<>();

        @NonNull
        @Override
        public ChangeVH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View row = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.row_change, parent, false);
            return new ChangeVH(row);
        }

        @Override
        public void onBindViewHolder(@NonNull ChangeVH holder, int position) {
            holder.bind(data.get(position));
        }

        @Override
        public int getItemCount() {
            return data.size();
        }

        void submit(@Nullable List<ActivityEvent> in) {
            data.clear();
            if (in != null) data.addAll(in);
            notifyDataSetChanged();
        }
    }

    // --------------- ViewHolder ----------------

    private static class ChangeVH extends RecyclerView.ViewHolder {
        final TextView tvText; // left column: time + message
        final TextView tvRight; // right column: short tag (e.g., type)

        ChangeVH(@NonNull View itemView) {
            super(itemView);
            tvText  = itemView.findViewById(R.id.tvChangeText);
            tvRight = itemView.findViewById(R.id.tvChangeQty);
        }

        void bind(ActivityEvent e) {
            // Format time like "7:32 PM" (use device locale)
            String when = DateFormat.getTimeInstance(DateFormat.SHORT)
                    .format(new Date(e.timeMillis));

            // Left: "7:32 PM • Item Chairs qty set to 12"
            tvText.setText(when + " • " + e.message);

            // Right: show the event type (Added, Qty updated, Deleted, Low stock)
            tvRight.setText(e.type);
        }
    }
}







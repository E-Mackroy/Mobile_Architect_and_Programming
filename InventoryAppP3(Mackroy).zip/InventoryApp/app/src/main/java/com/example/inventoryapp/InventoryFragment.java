package com.example.inventoryapp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class InventoryFragment extends Fragment {

    private ItemsViewModel viewModel;
    private ItemAdapter adapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_inventory, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View root, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(root, savedInstanceState);

        // Shared VM across activity so all tabs see the same data
        viewModel = new ViewModelProvider(requireActivity()).get(ItemsViewModel.class);
        viewModel.seedIfEmpty();

        // List setup
        RecyclerView rv = root.findViewById(R.id.rvInventory);
        rv.setLayoutManager(new LinearLayoutManager(requireContext()));
        adapter = new ItemAdapter();
        rv.setAdapter(adapter);

        // Keep UI in sync with data
        viewModel.getItems().observe(getViewLifecycleOwner(), adapter::setData);

        // Edit flow (qty update / delete)
        adapter.setOnEditRequest((position, item) -> {
            EditItemDialog.show(
                    requireContext(),
                    item.name,          // show item name in the dialog title
                    item.qty,
                    new EditItemDialog.Callback() {
                        @Override public void onSave(int newQty) {
                            viewModel.updateQty(position, newQty);
                        }
                        @Override public void onDelete() {
                            viewModel.deleteAt(position);
                        }
                    }
            );
        });

        // Add new item
        FloatingActionButton fab = root.findViewById(R.id.fabAddItem);
        fab.setOnClickListener(v ->
                AddItemDialog.show(requireContext(), (name, location, qty) ->
                        viewModel.addAtTop(new Item(name, location, qty)))
        );

        // ONE-SHOT LOW-STOCK POPUP
        // This will only fire the first time after a low-stock transition.
        viewModel.getLastAlertEvent().observe(getViewLifecycleOwner(), event -> {
            if (event == null) return;
            Alert a = event.getIfNotHandled();   // <- returns null if already handled
            if (a == null) return;

            new MaterialAlertDialogBuilder(requireContext())
                    .setTitle(R.string.low_stock_title)
                    .setMessage(a.message)
                    .setCancelable(false)                 // require explicit acknowledge
                    .setPositiveButton(R.string.accept, (d, w) -> d.dismiss())
                    .show();
        });
    }
}


















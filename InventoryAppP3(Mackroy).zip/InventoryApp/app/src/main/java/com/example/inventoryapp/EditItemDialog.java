package com.example.inventoryapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;

import androidx.annotation.NonNull;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;

public final class EditItemDialog {

    public interface Callback {
        void onSave(int newQty);
        void onDelete();
    }

    public static void show(@NonNull Context ctx, @NonNull String itemName, int initialQty, @NonNull Callback cb) {
        View content = LayoutInflater.from(ctx).inflate(R.layout.dialog_edit_item, null, false);
        EditText input = content.findViewById(R.id.inQtyEdit);
        input.setText(String.valueOf(initialQty));
        input.setSelection(input.getText().length());

        new MaterialAlertDialogBuilder(ctx)
                .setTitle(ctx.getString(R.string.title_edit_qty_for, itemName))
                .setView(content)
                .setNegativeButton(R.string.cancel, null)
                .setPositiveButton(R.string.save, (d, w) -> {
                    int value = initialQty;
                    try { value = Integer.parseInt(input.getText().toString().trim()); } catch (Exception ignore) {}
                    cb.onSave(value);
                })
                .setNeutralButton(R.string.delete, (d, w) -> cb.onDelete())
                .show();
    }
}








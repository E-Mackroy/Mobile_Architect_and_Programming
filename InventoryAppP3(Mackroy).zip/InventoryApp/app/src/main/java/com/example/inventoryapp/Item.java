package com.example.inventoryapp;

public class Item {
    public final String name;
    public final String location;
    public int qty;

    public Item(String name, String location, int qty) {
        this.name = name;
        this.location = location;
        this.qty = qty;
    }
}









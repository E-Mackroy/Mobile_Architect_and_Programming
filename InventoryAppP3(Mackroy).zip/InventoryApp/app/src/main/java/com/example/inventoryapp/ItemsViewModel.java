package com.example.inventoryapp;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ItemsViewModel extends ViewModel {

    public static final int LOW_STOCK = 15;

    private final MutableLiveData<List<Item>> items = new MutableLiveData<>(new ArrayList<>());
    private final MutableLiveData<List<ActivityEvent>> activity = new MutableLiveData<>(new ArrayList<>());
    private final MutableLiveData<List<Alert>> alerts = new MutableLiveData<>(new ArrayList<>());

    // <-- changed to one-shot wrapper
    private final MutableLiveData<OneShotEvent<Alert>> lastAlertEvent = new MutableLiveData<>(null);

    private final MutableLiveData<Boolean> smsEnabled = new MutableLiveData<>(false);

    // tracks which items are currently "low", so we only alert on downward crossing
    private final Set<String> lowStockKeys = new HashSet<>();

    public LiveData<List<Item>> getItems() { return items; }
    public LiveData<List<ActivityEvent>> getActivity() { return activity; }
    public LiveData<List<Alert>> getAlerts() { return alerts; }
    public LiveData<OneShotEvent<Alert>> getLastAlertEvent() { return lastAlertEvent; }
    public LiveData<Boolean> getSmsEnabled() { return smsEnabled; }
    public void enableSms(boolean granted) { smsEnabled.setValue(granted); }
    public boolean isSmsEnabled() { Boolean b = smsEnabled.getValue(); return b != null && b; }

    public void seedIfEmpty() {
        List<Item> cur = safe(items.getValue());
        if (cur.isEmpty()) {
            ArrayList<Item> seed = new ArrayList<>();
            seed.add(new Item("Bags", "A101", 48));
            seed.add(new Item("Tape Rolls", "A102", 63));
            items.setValue(seed);
        }
    }

    public void addAtTop(@NonNull Item it) {
        ArrayList<Item> cur = new ArrayList<>(safe(items.getValue()));
        cur.add(0, it);
        items.setValue(cur);
        addActivity(new ActivityEvent(System.currentTimeMillis(), "Added",
                "Item " + it.name + " added with qty " + it.qty));
        checkLowStockTransition(it);
    }

    public void updateQty(int position, int newQty) {
        ArrayList<Item> cur = new ArrayList<>(safe(items.getValue()));
        if (position < 0 || position >= cur.size()) return;

        Item old = cur.get(position);
        Item up  = new Item(old.name, old.location, newQty);
        cur.set(position, up);
        items.setValue(cur);

        addActivity(new ActivityEvent(System.currentTimeMillis(), "Qty updated",
                "Item " + up.name + " qty set to " + up.qty));

        checkLowStockTransition(up); // handles one-shot alerting
    }

    public void deleteAt(int position) {
        ArrayList<Item> cur = new ArrayList<>(safe(items.getValue()));
        if (position < 0 || position >= cur.size()) return;
        Item removed = cur.remove(position);
        items.setValue(cur);

        lowStockKeys.remove(keyOf(removed)); // allow future re-add to alert correctly
        addActivity(new ActivityEvent(System.currentTimeMillis(), "Deleted",
                "Item " + removed.name + " removed"));
    }

    public void addActivity(@NonNull ActivityEvent e) {
        ArrayList<ActivityEvent> cur = new ArrayList<>(safe(activity.getValue()));
        cur.add(0, e);
        activity.setValue(cur);
    }

    private void addAlert(@NonNull String message) {
        Alert a = new Alert(System.currentTimeMillis(), message);
        ArrayList<Alert> cur = new ArrayList<>(safe(alerts.getValue()));
        cur.add(0, a);
        alerts.setValue(cur);

        // <-- post as a one-shot event
        lastAlertEvent.setValue(new OneShotEvent<>(a));
    }

    /** Only alert when crossing LOW_STOCK from above to below;
     *  clear tracking when we cross back to >= LOW_STOCK. */
    private void checkLowStockTransition(@NonNull Item it) {
        String key = keyOf(it);
        boolean isLow = it.qty < LOW_STOCK;
        boolean wasLow = lowStockKeys.contains(key);

        if (isLow && !wasLow) {
            String msg = "Low stock: " + it.name + " = " + it.qty;
            addAlert(msg);
            addActivity(new ActivityEvent(System.currentTimeMillis(), "Low stock", msg));
            lowStockKeys.add(key);
        } else if (!isLow && wasLow) {
            // crossed upward out of low: stop alerting for this item until it drops again
            lowStockKeys.remove(key);
        }
        // else: no state change -> no new alert
    }

    private static String keyOf(@NonNull Item it) {
        return it.name + "|" + it.location; // swap to a stable ID if you add one later
    }

    private static <T> List<T> safe(List<T> in) {
        return (in == null) ? Collections.emptyList() : in;
    }
}
















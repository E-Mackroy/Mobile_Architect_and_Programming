package com.example.inventoryapp;

/** Simple model for an alert row. */
public class Alert {
    public final long timeMillis;
    public final String message;

    public Alert(long timeMillis, String message) {
        this.timeMillis = timeMillis;
        this.message = message;
    }
}



package com.example.inventoryapp;

/** Wraps a value so it can be handled only once by observers. */
public final class OneShotEvent<T> {
    private final T value;
    private boolean handled = false;

    public OneShotEvent(T value) { this.value = value; }

    /** Returns the value the first time; null on subsequent calls. */
    public T getIfNotHandled() {
        if (handled) return null;
        handled = true;
        return value;
    }

    /** Returns the value without marking it handled (use sparingly). */
    public T peek() { return value; }
}



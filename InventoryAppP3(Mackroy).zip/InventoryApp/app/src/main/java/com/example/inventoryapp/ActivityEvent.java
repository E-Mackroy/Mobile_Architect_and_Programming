package com.example.inventoryapp;

/** Simple value object for a row in the Activity feed. */
public class ActivityEvent {
    /** Event timestamp (System.currentTimeMillis()). */
    public final long timeMillis;

    /** Short type label like "Added", "Qty updated", "Deleted", "Low stock". */
    public final String type;

    /** Human-readable message shown in the feed. */
    public final String message;

    public ActivityEvent(long timeMillis, String type, String message) {
        this.timeMillis = timeMillis;
        this.type = type;
        this.message = message;
    }
}




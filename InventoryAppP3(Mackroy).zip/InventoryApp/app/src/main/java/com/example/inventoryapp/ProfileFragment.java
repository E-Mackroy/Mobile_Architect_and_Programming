package com.example.inventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class ProfileFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_profile, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);


        TextView tvName  = view.findViewById(R.id.tvName);
        TextView tvEmail = view.findViewById(R.id.tvEmail);
        Button btnChange = view.findViewById(R.id.btnChangePassword);
        Button btnSignOut = view.findViewById(R.id.btnSignOut);


        if (tvName != null)  tvName.setText("Name: Erek M.");
        if (tvEmail != null) tvEmail.setText("Email: Erek@example.com");

        if (btnChange != null) {
            btnChange.setOnClickListener(v -> {
                // Hook up your real change-password flow here
                Toast.makeText(requireContext(), "Change password tapped", Toast.LENGTH_SHORT).show();
            });
        }

        if (btnSignOut != null) {
            btnSignOut.setOnClickListener(v -> {
                // Navigate back to the sign-in screen and clear this task so back does not return
                Intent i = new Intent(requireContext(), LoginActivity.class);
                i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
                requireActivity().finish();
            });
        }
    }
}




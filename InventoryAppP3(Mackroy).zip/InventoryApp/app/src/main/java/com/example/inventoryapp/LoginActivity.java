package com.example.inventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        EditText email = findViewById(R.id.etEmail);
        EditText pass  = findViewById(R.id.etPassword);
        Button btnSignIn = findViewById(R.id.btnSignIn);
        Button btnCreate = findViewById(R.id.btnCreateAccount);

        // For this project, both buttons go to MainActivity
        btnSignIn.setOnClickListener(v ->
                startActivity(new Intent(this, MainActivity.class)));

        btnCreate.setOnClickListener(v ->
                startActivity(new Intent(this, MainActivity.class)));
    }
}


package com.example.inventoryapp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Shows saved alerts. Uses row_change.xml with:
 *  - @id/tvChangeText (left)  : time + message
 *  - @id/tvChangeQty  (right) : "ALERT"
 */
public class AlertsFragment extends Fragment {

    private ItemsViewModel vm;
    private AlertsAdapter adapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_alerts, container, false);

        vm = new ViewModelProvider(requireActivity()).get(ItemsViewModel.class);

        RecyclerView rv = root.findViewById(R.id.rvAlerts);
        rv.setLayoutManager(new LinearLayoutManager(requireContext()));
        adapter = new AlertsAdapter();
        rv.setAdapter(adapter);

        // <<< This is the call that failed before; it's now available in ViewModel >>>
        vm.getAlerts().observe(getViewLifecycleOwner(), adapter::submit);

        return root;
    }

    // ---------------- Adapter ----------------

    private static class AlertsAdapter extends RecyclerView.Adapter<AlertVH> {
        private final List<Alert> data = new ArrayList<>();

        @NonNull @Override
        public AlertVH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View row = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.row_change, parent, false);
            return new AlertVH(row);
        }

        @Override
        public void onBindViewHolder(@NonNull AlertVH holder, int position) {
            holder.bind(data.get(position));
        }

        @Override
        public int getItemCount() { return data.size(); }

        void submit(@Nullable List<Alert> in) {
            data.clear();
            if (in != null) data.addAll(in);
            notifyDataSetChanged();
        }
    }

    // --------------- ViewHolder ----------------

    private static class AlertVH extends RecyclerView.ViewHolder {
        final TextView tvText;
        final TextView tvRight;

        AlertVH(@NonNull View itemView) {
            super(itemView);
            tvText  = itemView.findViewById(R.id.tvChangeText);
            tvRight = itemView.findViewById(R.id.tvChangeQty);
        }

        void bind(Alert a) {
            String when = DateFormat.getTimeInstance(DateFormat.SHORT)
                    .format(new Date(a.timeMillis));
            tvText.setText(when + " • " + a.message);
            tvRight.setText("ALERT");
        }
    }
}




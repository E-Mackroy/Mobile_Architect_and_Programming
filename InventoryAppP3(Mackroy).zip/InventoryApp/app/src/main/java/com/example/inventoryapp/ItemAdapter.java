package com.example.inventoryapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.RowVH> {

    public interface OnEditRequest {
        void onEdit(int position, Item item);
    }

    private final List<Item> data = new ArrayList<>();
    private OnEditRequest onEditRequest;

    public void setOnEditRequest(OnEditRequest cb) { this.onEditRequest = cb; }

    public void setData(List<Item> items) {
        data.clear();
        if (items != null) data.addAll(items);
        notifyDataSetChanged();
    }

    @NonNull @Override
    public RowVH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View row = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_inventory_item, parent, false);
        return new RowVH(row);
    }

    @Override
    public void onBindViewHolder(@NonNull RowVH h, int position) {
        Item it = data.get(position);
        h.tvName.setText(it.name);
        h.tvLocation.setText(it.location);
        h.tvQty.setText(String.valueOf(it.qty));
        h.btnEdit.setOnClickListener(v -> {
            if (onEditRequest != null) onEditRequest.onEdit(h.getBindingAdapterPosition(), it);
        });
    }

    @Override public int getItemCount() { return data.size(); }

    static class RowVH extends RecyclerView.ViewHolder {
        final TextView tvName, tvLocation, tvQty;
        final ImageButton btnEdit;
        RowVH(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tvName);
            tvLocation = itemView.findViewById(R.id.tvLocation);
            tvQty = itemView.findViewById(R.id.tvQty);
            btnEdit = itemView.findViewById(R.id.btnEdit);
        }
    }
}






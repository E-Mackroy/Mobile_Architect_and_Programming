package com.example.inventoryapp;

import android.Manifest;
import android.os.Bundle;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;   // <-- IMPORTANT

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    private static final String KEY_PROMPTED = "sms_prompted_this_session";
    private boolean promptedThisSession = false;

    private final ActivityResultLauncher<String> smsPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
                // Push the result into the shared ViewModel so the rest of the app can react.
                ItemsViewModel vm = new ViewModelProvider(this).get(ItemsViewModel.class);
                vm.enableSms(granted);
            });

    private void show(Fragment f) {
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragment_container_view, f)
                .commit();
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (savedInstanceState != null) {
            promptedThisSession = savedInstanceState.getBoolean(KEY_PROMPTED, false);
        }

        BottomNavigationView bottom = findViewById(R.id.bottom_nav);

        // default screen
        show(new InventoryFragment());
        bottom.setSelectedItemId(R.id.menu_inventory);

        bottom.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.menu_inventory)      show(new InventoryFragment());
            else if (id == R.id.menu_alerts)     show(new AlertsFragment());
            else if (id == R.id.menu_activity)   show(new ActivityFragment());
            else if (id == R.id.menu_profile)    show(new ProfileFragment());
            return true;
        });

        // Auto-prompt for SMS permission once per app session (after login)
        if (!promptedThisSession) {
            promptedThisSession = true;
            smsPermissionLauncher.launch(Manifest.permission.SEND_SMS);
        }
    }

    @Override
    protected void onSaveInstanceState(@Nullable Bundle outState) {
        super.onSaveInstanceState(outState);
        if (outState != null) outState.putBoolean(KEY_PROMPTED, promptedThisSession);
    }
}


